import os
from dotenv import load_dotenv
load_dotenv()

def ask_assistant(question: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return "Add your GEMINI_API_KEY to the local .env file."
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        response = client.models.generate_content(model=model, contents=question)
        return response.text or "No response generated."
    except Exception as exc:
        return f"AI service error: {exc}"

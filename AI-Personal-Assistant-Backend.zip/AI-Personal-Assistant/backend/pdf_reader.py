from pathlib import Path
import fitz

def extract_pdf_text(file_path: str) -> str:
    path = Path(file_path)
    if not path.is_file() or path.suffix.lower() != ".pdf":
        raise ValueError("Provide an existing PDF file.")
    with fitz.open(path) as document:
        return "\\n".join(page.get_text() for page in document)

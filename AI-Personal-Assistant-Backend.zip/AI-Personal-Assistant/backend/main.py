from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .ai_engine import ask_assistant
from .pdf_reader import extract_pdf_text
from .database import init_db

app = FastAPI(title="AI Personal Assistant", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def startup():
    init_db()

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/ask")
def ask(payload: dict):
    question = str(payload.get("question", "")).strip()
    if not question:
        return {"error": "Please provide a question."}
    return {"answer": ask_assistant(question)}

@app.post("/api/pdf-text")
def pdf_text(payload: dict):
    file_path = payload.get("file_path")
    if not file_path:
        return {"error": "Provide a server-side PDF file_path."}
    return {"text": extract_pdf_text(file_path)}

# AI Personal Assistant — Backend Starter

## Included
- FastAPI backend with health, AI question, and PDF text endpoints
- Gemini API integration
- PDF text extraction with PyMuPDF
- SQLite database initialization
- Password hashing helpers
- Uploads and screenshots folders
- Environment templates and Git ignore rules

## Run later (Windows PowerShell)
```powershell
python -m venv venv
.\\venv\\Scripts\\Activate.ps1
python -m pip install -r requirements.txt
```
Add your own Gemini key to `.env`, then run:
```powershell
python -m uvicorn backend.main:app --reload
```
API documentation: http://127.0.0.1:8000/docs

## Important
This is a starter backend, not a fully tested finished application. Login/register API routes and browser-based PDF upload are not implemented yet. The PDF endpoint currently reads a PDF path already available on the server. Never upload `.env` or real API keys to GitHub. Before deployment, restrict CORS and add production-grade authentication, validation, and upload limits.
